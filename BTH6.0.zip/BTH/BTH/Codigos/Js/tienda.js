// Estado de la tienda
let products = [];
let wishlist = [];
let cart = [];
let currentProductId = null;

// Configuración de Airtable para productos
const AIRTABLE_PRODUCTS_CONFIG = {
    ACCESS_TOKEN: 'patgXXuC5Cc2fOXLX.f742cfd9463aeb945440e76b471c59114e54ac1e3c42fb5300d76ab026daf7bd',
    BASE_ID: 'appovrtUpixz5DBRW',  
    TABLE_NAME: 'Productos'
};

// Inicializar tienda
async function initializeStore() {
    console.log('🏪 Inicializando tienda...');
    
    try {
        await loadProducts();
        console.log('📦 Productos cargados:', products.length);
        
        // Verificar y deshabilitar productos agotados
        await disableOutOfStockProducts();
        
        await loadUserData();
        console.log('👤 Datos de usuario cargados');
        
        renderProducts();
        console.log('🎨 Productos renderizados');
        
        updateHeader();
        console.log('🔤 Header actualizado');
        
    } catch (error) {
        console.error('❌ Error inicializando tienda:', error);
        showErrorMessage('Error cargando la tienda. Recarga la página.');
    }
}

// Cargar productos desde Airtable
async function loadProducts() {
    try {
        console.log('📦 Cargando productos desde Airtable...');
        products = await airtableService.getProducts();
        console.log(`✅ ${products.length} productos cargados`);
        
        // Filtrar solo productos disponibles (con stock y activos)
        products = products.filter(product => 
            product.isAvailable && 
            product.status !== 'sold' && 
            product.stock > 0
        );
        
    } catch (error) {
        console.error('❌ Error cargando productos:', error);
        products = [];
        showErrorMessage('Error cargando productos. Intenta recargar la página.');
    }
}

// Cargar datos del usuario
async function loadUserData() {
    if (authService.isAuthenticated()) {
        const userId = authService.getCurrentUser().id;
        try {
            console.log('👤 Cargando datos del usuario...');
            
            // Cargar wishlist
            const wishlistData = await airtableService.getUserWishlist(userId);
            wishlist = wishlistData.map(record => ({
                recordId: record.id,
                productId: record.fields.ProductID,
                isSelected: record.fields.IsSelected || false
            }));
            
            // Cargar carrito
            const cartData = await airtableService.getUserCart(userId);
            cart = cartData.map(record => ({
                recordId: record.id,
                productId: record.fields.ProductID,
                quantity: record.fields.Quantity || 1
            }));
            
        } catch (error) {
            console.error('❌ Error cargando datos usuario:', error);
        }
    }
}

// Renderizar productos
function renderProducts() {
    const productsGrid = document.getElementById('productsGrid');
    const loadingState = document.getElementById('loadingState');
    const emptyState = document.getElementById('emptyState');

    if (!productsGrid) return;

    // Ocultar estado de carga
    if (loadingState) loadingState.style.display = 'none';

    if (products.length === 0) {
        // Mostrar estado vacío
        if (emptyState) emptyState.style.display = 'block';
        productsGrid.innerHTML = '';
        return;
    }

    // Ocultar estado vacío
    if (emptyState) emptyState.style.display = 'none';

    // Mostrar contador de productos
    const productCount = document.createElement('div');
    productCount.className = 'col-12 mb-3';
    productCount.innerHTML = `
        <div class="alert alert-light border">
            <small class="text-muted">
                <i class="bi bi-info-circle me-1"></i>
                Mostrando ${products.length} producto(s) disponible(s)
            </small>
        </div>
    `;

    // Renderizar productos
    productsGrid.innerHTML = '';
    productsGrid.appendChild(productCount);
    
    productsGrid.innerHTML += products.map(product => `
        <div class="col-lg-3 col-md-4 col-sm-6 product-item" 
             data-category="${product.category}" 
             data-name="${product.name.toLowerCase()}"
             onclick="openProductPopup('${product.id}')">
            <div class="card product-card h-100">
                <img src="${product.image}" class="card-img-top product-image" alt="${product.name}"
                     onerror="this.src='https://via.placeholder.com/300x200/4CAF50/FFFFFF?text=Imagen+No+Disponible'">
                <div class="card-body d-flex flex-column">
                    <span class="product-category">${product.category?.charAt(0)?.toUpperCase() + product.category?.slice(1) || 'Sin categoría'}</span>
                    <h5 class="card-title mt-2 flex-grow-1">${product.name}</h5>
                    <div class="mt-auto">
                        <div class="d-flex justify-content-between align-items-center">
                            <span class="product-price">$${product.price?.toLocaleString() || '0'}</span>
                            <div class="product-actions">
                                <button class="btn-wishlist" onclick="toggleWishlist('${product.id}', event)">
                                    <i class="bi bi-heart${wishlist.some(item => item.productId === product.id) ? '-fill text-danger' : ''}"></i>
                                </button>
                                <button class="btn-cart" onclick="addToCart('${product.id}', 1, event)" 
                                        ${!product.isAvailable || product.stock <= 0 ? 'disabled' : ''}>
                                    <i class="bi bi-cart-plus"></i>
                                </button>
                            </div>
                        </div>
                        <div class="product-stock-info mt-2">
                            ${product.stock > 0 ? 
                                `<span class="badge bg-success">${product.stock} disponibles</span>` : 
                                `<span class="badge bg-warning">Agotado</span>`
                            }
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `).join('');
}

// =============================================
// FUNCIONES WISHLIST
// =============================================

async function toggleWishlist(productId, event = null) {
    if (event) event.stopPropagation();
    
    if (!authService.isAuthenticated()) {
        alert('Debes iniciar sesión para usar la lista de deseos');
        return;
    }

    const userId = authService.getCurrentUser().id;
    
    try {
        const existingItem = wishlist.find(item => item.productId === productId);
        
        if (existingItem) {
            await airtableService.removeFromWishlist(existingItem.recordId);
            wishlist = wishlist.filter(item => item.productId !== productId);
            alert('❌ Eliminado de la lista de deseos');
        } else {
            const result = await airtableService.addToWishlist(userId, productId);
            wishlist.push({
                recordId: result.id,
                productId: productId,
                isSelected: false
            });
            alert('✅ Agregado a la lista de deseos');
        }
        
        renderProducts();
        if (document.getElementById('wishlistPopup').style.display === 'block') {
            renderWishlist();
        }
        
    } catch (error) {
        console.error('❌ Error actualizando wishlist:', error);
        alert('Error al actualizar la lista de deseos');
    }
}

function renderWishlist() {
    const wishlistBody = document.getElementById('wishlistBody');
    const wishlistEmpty = document.getElementById('wishlistEmpty');
    const wishlistContent = document.getElementById('wishlistContent');
    
    if (wishlist.length === 0) {
        wishlistEmpty.style.display = 'block';
        wishlistContent.style.display = 'none';
        return;
    }
    
    wishlistEmpty.style.display = 'none';
    wishlistContent.style.display = 'block';
    
    wishlistBody.innerHTML = wishlist.map(item => {
        const product = products.find(p => p.id === item.productId);
        if (!product) return '';
        
        return `
            <div class="wishlist-item ${item.isSelected ? 'selected' : ''}">
                <div class="wishlist-item-content">
                    <div class="form-check wishlist-check">
                        <input class="form-check-input" type="checkbox" 
                               ${item.isSelected ? 'checked' : ''} 
                               onchange="toggleWishlistSelection('${item.recordId}')">
                    </div>
                    
                    <div class="wishlist-product-info">
                        <img src="${product.image}" alt="${product.name}" 
                             class="wishlist-product-image" 
                             onerror="this.src='https://via.placeholder.com/60x60/4CAF50/FFFFFF?text=Imagen'">
                        <div class="wishlist-product-details">
                            <h6 class="wishlist-product-name">${product.name}</h6>
                            <div class="wishlist-product-meta">
                                <span class="wishlist-product-category">${product.category}</span>
                                <span class="wishlist-product-price">$${product.price?.toLocaleString() || '0'}</span>
                                <span class="wishlist-product-stock">${product.stock} disponibles</span>
                            </div>
                            <p class="wishlist-product-description">${product.description?.substring(0, 100)}${product.description?.length > 100 ? '...' : ''}</p>
                        </div>
                    </div>
                    
                    <button class="btn btn-sm btn-outline-danger wishlist-remove" 
                            onclick="removeFromWishlist('${item.recordId}')"
                            title="Eliminar de la lista de deseos">
                        <i class="bi bi-trash"></i>
                    </button>
                </div>
            </div>
        `;
    }).join('');
    
    updateWishlistActions();
}

function toggleWishlistSelection(recordId) {
    const item = wishlist.find(item => item.recordId === recordId);
    if (item) {
        item.isSelected = !item.isSelected;
        renderWishlist();
    }
}

function selectAllWishlist() {
    const allSelected = wishlist.every(item => item.isSelected);
    wishlist.forEach(item => {
        item.isSelected = !allSelected;
    });
    renderWishlist();
}

async function removeFromWishlist(recordId) {
    try {
        await airtableService.removeFromWishlist(recordId);
        wishlist = wishlist.filter(item => item.recordId !== recordId);
        renderWishlist();
        renderProducts();
    } catch (error) {
        console.error('Error eliminando de wishlist:', error);
        alert('❌ Error al eliminar de la lista de deseos');
    }
}

async function clearWishlist() {
    if (wishlist.length === 0) return;
    
    if (!confirm('¿Estás seguro de que quieres eliminar todos los items de tu lista de deseos?')) {
        return;
    }
    
    try {
        for (const item of wishlist) {
            await airtableService.removeFromWishlist(item.recordId);
        }
        wishlist = [];
        renderWishlist();
        renderProducts();
    } catch (error) {
        console.error('Error limpiando wishlist:', error);
        alert('❌ Error al limpiar la lista de deseos');
    }
}

async function addSelectedToCart() {
    const selectedItems = wishlist.filter(item => item.isSelected);
    
    if (selectedItems.length === 0) {
        alert('Selecciona al menos un producto para agregar al carrito');
        return;
    }
    
    const userId = authService.getCurrentUser().id;
    let addedCount = 0;
    let errors = [];
    
    for (const item of selectedItems) {
        try {
            const product = products.find(p => p.id === item.productId);
            if (product && product.stock > 0) {
                await airtableService.addToCart(userId, item.productId, 1);
                addedCount++;
                await airtableService.removeFromWishlist(item.recordId);
            } else {
                errors.push(`${product.name} (sin stock)`);
            }
        } catch (error) {
            console.error(`Error agregando producto ${item.productId} al carrito:`, error);
            errors.push(item.productId);
        }
    }
    
    wishlist = wishlist.filter(item => !item.isSelected);
    await loadUserData();
    renderWishlist();
    renderProducts();
    
    if (errors.length === 0) {
        alert(`✅ ${addedCount} producto(s) agregado(s) al carrito`);
    } else {
        alert(`✅ ${addedCount} producto(s) agregado(s), ❌ ${errors.length} con error: ${errors.join(', ')}`);
    }
}

function updateWishlistActions() {
    const selectedCount = wishlist.filter(item => item.isSelected).length;
    const selectAllBtn = document.getElementById('selectAllWishlist');
    const addToCartBtn = document.getElementById('addSelectedToCart');
    const clearAllBtn = document.getElementById('clearWishlist');
    
    if (selectAllBtn) {
        selectAllBtn.textContent = wishlist.every(item => item.isSelected) ? 
            'Deseleccionar Todos' : 'Seleccionar Todos';
    }
    
    if (addToCartBtn) {
        addToCartBtn.disabled = selectedCount === 0;
        addToCartBtn.innerHTML = selectedCount > 0 ? 
            `<i class="bi bi-cart-plus"></i> Agregar (${selectedCount}) al Carrito` :
            `<i class="bi bi-cart-plus"></i> Agregar al Carrito`;
    }
    
    if (clearAllBtn) {
        clearAllBtn.disabled = wishlist.length === 0;
    }
}

// =============================================
// FUNCIONES CARRITO CON STOCK
// =============================================

async function addToCart(productId, quantity = 1, event = null) {
    if (event) event.stopPropagation();
    
    if (!authService.isAuthenticated()) {
        alert('Debes iniciar sesión para agregar al carrito');
        return;
    }

    const product = products.find(p => p.id === productId);
    if (!product || !product.isAvailable) {
        alert('❌ Este producto no está disponible');
        return;
    }

    if (product.stock <= 0) {
        alert('❌ Este producto está agotado');
        return;
    }

    const userId = authService.getCurrentUser().id;
    
    try {
        const existingItem = cart.find(item => item.productId === productId);
        const currentQuantity = existingItem ? existingItem.quantity : 0;
        const newTotalQuantity = currentQuantity + quantity;
        
        // Verificar stock disponible
        if (newTotalQuantity > product.stock) {
            alert(`❌ Solo hay ${product.stock} unidades disponibles. Ya tienes ${currentQuantity} en el carrito.`);
            return;
        }
        
        if (existingItem) {
            await airtableService.updateCartItem(existingItem.recordId, newTotalQuantity);
            existingItem.quantity = newTotalQuantity;
        } else {
            const result = await airtableService.addToCart(userId, productId, quantity);
            cart.push({
                recordId: result.id,
                productId: productId,
                quantity: quantity
            });
        }
        
        alert('✅ Producto agregado al carrito');
        
        if (document.getElementById('cartPopup').style.display === 'block') {
            renderCart();
        }
        
    } catch (error) {
        console.error('❌ Error agregando al carrito:', error);
        alert('❌ Error al agregar al carrito');
    }
}

function renderCart() {
    const cartBody = document.getElementById('cartBody');
    const cartEmpty = document.getElementById('cartEmpty');
    const cartContent = document.getElementById('cartContent');
    const cartTotal = document.getElementById('cartTotal');
    
    if (cart.length === 0) {
        cartEmpty.style.display = 'block';
        cartContent.style.display = 'none';
        return;
    }
    
    cartEmpty.style.display = 'none';
    cartContent.style.display = 'block';
    
    let total = 0;
    
    cartBody.innerHTML = cart.map(item => {
        const product = products.find(p => p.id === item.productId);
        if (!product) return '';
        
        const itemTotal = product.price * item.quantity;
        total += itemTotal;
        const maxAvailable = product.stock;
        
        return `
            <div class="cart-item">
                <div class="cart-item-content">
                    <img src="${product.image}" alt="${product.name}" 
                         class="cart-product-image"
                         onerror="this.src='https://via.placeholder.com/60x60/4CAF50/FFFFFF?text=Imagen'">
                    
                    <div class="cart-product-info">
                        <h6 class="cart-product-name">${product.name}</h6>
                        <div class="cart-product-meta">
                            <span class="cart-product-category">${product.category}</span>
                            <span class="cart-product-stock">${maxAvailable} disponibles</span>
                        </div>
                    </div>
                    
                    <div class="cart-quantity-controls">
                        <button class="btn btn-sm btn-outline-secondary" 
                                onclick="updateCartQuantity('${item.recordId}', ${item.quantity - 1})"
                                ${item.quantity <= 1 ? 'disabled' : ''}>
                            <i class="bi bi-dash"></i>
                        </button>
                        <span class="cart-quantity">${item.quantity}</span>
                        <button class="btn btn-sm btn-outline-secondary" 
                                onclick="updateCartQuantity('${item.recordId}', ${item.quantity + 1})"
                                ${item.quantity >= maxAvailable ? 'disabled' : ''}>
                            <i class="bi bi-plus"></i>
                        </button>
                    </div>
                    
                    <div class="cart-item-total">
                        $${itemTotal.toLocaleString()}
                    </div>
                    
                    <button class="btn btn-sm btn-outline-danger cart-remove" 
                            onclick="removeFromCart('${item.recordId}')"
                            title="Eliminar del carrito">
                        <i class="bi bi-trash"></i>
                    </button>
                </div>
            </div>
        `;
    }).join('');
    
    cartTotal.textContent = `$${total.toLocaleString()}`;
    updateCartActions();
}

async function updateCartQuantity(recordId, newQuantity) {
    if (newQuantity < 1) {
        removeFromCart(recordId);
        return;
    }
    
    try {
        const item = cart.find(item => item.recordId === recordId);
        const product = products.find(p => p.id === item.productId);
        
        // Verificar stock
        if (newQuantity > product.stock) {
            alert(`❌ Solo hay ${product.stock} unidades disponibles`);
            return;
        }
        
        await airtableService.updateCartItem(recordId, newQuantity);
        item.quantity = newQuantity;
        renderCart();
    } catch (error) {
        console.error('Error actualizando cantidad:', error);
        alert('❌ Error al actualizar la cantidad');
    }
}

async function removeFromCart(recordId) {
    try {
        await airtableService.removeFromCart(recordId);
        cart = cart.filter(item => item.recordId !== recordId);
        renderCart();
    } catch (error) {
        console.error('Error eliminando del carrito:', error);
        alert('❌ Error al eliminar del carrito');
    }
}

async function clearCart() {
    if (cart.length === 0) return;
    
    if (!confirm('¿Estás seguro de que quieres vaciar tu carrito?')) {
        return;
    }
    
    try {
        for (const item of cart) {
            await airtableService.removeFromCart(item.recordId);
        }
        cart = [];
        renderCart();
    } catch (error) {
        console.error('Error vaciando carrito:', error);
        alert('❌ Error al vaciar el carrito');
    }
}

// Función para actualizar stock de productos en Airtable
async function updateProductStock(productId, newStock, isAvailable) {
    try {
        const response = await fetch(`https://api.airtable.com/v0/${AIRTABLE_PRODUCTS_CONFIG.BASE_ID}/${AIRTABLE_PRODUCTS_CONFIG.TABLE_NAME}/${productId}`, {
            method: 'PATCH',
            headers: {
                'Authorization': `Bearer ${AIRTABLE_PRODUCTS_CONFIG.ACCESS_TOKEN}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                fields: {
                    "Stock": newStock,
                    "IsAvailable": isAvailable,
                    "Status": isAvailable ? "available" : "sold"
                }
            })
        });

        if (!response.ok) {
            throw new Error(`Error ${response.status}: ${await response.text()}`);
        }
        
        return await response.json();
    } catch (error) {
        console.error('❌ Error actualizando stock:', error);
        throw error;
    }
}

async function checkout() {
    if (cart.length === 0) {
        alert('Tu carrito está vacío');
        return;
    }
    
    if (!confirm('¿Confirmas que deseas realizar la compra?')) {
        return;
    }
    
    try {
        const userId = authService.getCurrentUser().id;
        let successfulPurchases = 0;
        let totalItems = 0;
        const orderId = 'ORD-' + Date.now(); // ID único para la orden
        
        // Actualizar stock y procesar compra
        for (const item of cart) {
            const product = products.find(p => p.id === item.productId);
            if (product) {
                const newStock = product.stock - item.quantity;
                const isAvailable = newStock > 0;
                
                try {
                    // Actualizar stock en Airtable
                    await updateProductStock(product.id, newStock, isAvailable);
                    
                    // Guardar en historial de compras
                    await airtableService.addToPurchaseHistory({
                        userId: userId,
                        productId: product.id,
                        productName: product.name,
                        quantity: item.quantity,
                        unitPrice: product.price,
                        orderId: orderId
                    });
                    
                    successfulPurchases++;
                    totalItems += item.quantity;
                    
                } catch (error) {
                    console.error(`❌ Error actualizando producto ${product.name}:`, error);
                }
            }
        }
        
        // Vaciar carrito después de la compra exitosa
        for (const item of cart) {
            try {
                await airtableService.removeFromCart(item.recordId);
            } catch (error) {
                console.error('Error eliminando item del carrito:', error);
            }
        }
        
        cart = [];
        
        // Mostrar mensaje de felicitación
        showCheckoutSuccess(successfulPurchases, totalItems);
        
        // Recargar productos para actualizar estado
        await loadProducts();
        renderProducts();
        renderCart();
        
    } catch (error) {
        console.error('Error en checkout:', error);
        alert('❌ Error al procesar la compra. Intenta nuevamente.');
    }
}

function showCheckoutSuccess(purchasesCount, totalItems) {
    const checkoutSuccess = document.getElementById('checkoutSuccess');
    
    checkoutSuccess.innerHTML = `
        <div class="text-center">
            <i class="bi bi-check-circle-fill text-success display-4"></i>
            <h4 class="mt-3 text-success">¡Felicidades! Compra realizada exitosamente</h4>
            <p class="mb-2">
                <strong>${purchasesCount} producto(s)</strong> comprado(s) - 
                <strong>${totalItems} unidad(es)</strong> en total
            </p>
            <p class="mb-0 text-muted">
                Los productos han sido procesados y pronto llegarán a ti.
            </p>
            ${totalItems > 0 ? `<p class="mt-2"><small>✅ Stock actualizado correctamente</small></p>` : ''}
        </div>
    `;
    
    checkoutSuccess.style.display = 'block';
    checkoutSuccess.className = 'alert alert-success mt-3';
    
    // Cerrar automáticamente después de 5 segundos
    setTimeout(() => {
        checkoutSuccess.style.display = 'none';
        closeCartPopup();
    }, 5000);
}

function updateCartActions() {
    const clearCartBtn = document.getElementById('clearCart');
    const checkoutBtn = document.getElementById('checkoutBtn');
    
    if (clearCartBtn) {
        clearCartBtn.disabled = cart.length === 0;
    }
    
    if (checkoutBtn) {
        checkoutBtn.disabled = cart.length === 0;
    }
}

// =============================================
// POPUP DETALLES PRODUCTO CON STOCK
// =============================================

function openProductPopup(productId) {
    const product = products.find(p => p.id === productId);
    if (!product) return;

    currentProductId = productId;

    document.getElementById('popupProductName').textContent = product.name;
    document.getElementById('popupProductImage').src = product.image;
    document.getElementById('popupProductCategory').textContent = 
        product.category?.charAt(0)?.toUpperCase() + product.category?.slice(1) || 'Sin categoría';
    document.getElementById('popupProductPrice').textContent = `$${product.price?.toLocaleString() || '0'}`;
    document.getElementById('popupProductDescription').textContent = product.description || 'Sin descripción disponible';
    document.getElementById('popupProductCreatedBy').textContent = product.createdBy || 'Anónimo';
    
    const statusBadge = document.getElementById('popupProductStatus');
    const stockInfo = document.getElementById('popupProductStock');
    
    if (product.isAvailable && product.stock > 0) {
        statusBadge.textContent = 'Disponible';
        statusBadge.className = 'badge bg-success';
        stockInfo.textContent = `${product.stock} unidades disponibles`;
        stockInfo.className = 'text-success';
    } else {
        statusBadge.textContent = 'Agotado';
        statusBadge.className = 'badge bg-warning';
        stockInfo.textContent = 'Producto agotado';
        stockInfo.className = 'text-danger';
    }

    const wishlistBtn = document.getElementById('wishlistBtn');
    const cartBtn = document.getElementById('cartBtn');
    
    const isInWishlist = wishlist.some(item => item.productId === productId);
    wishlistBtn.innerHTML = isInWishlist ? 
        '<i class="bi bi-heart-fill"></i> En wishlist' : 
        '<i class="bi bi-heart"></i> Wishlist';
    
    wishlistBtn.className = isInWishlist ? 
        'btn btn-danger me-2' : 'btn btn-outline-danger me-2';

    cartBtn.disabled = !product.isAvailable || product.stock <= 0;
    cartBtn.innerHTML = cartBtn.disabled ? 
        '<i class="bi bi-cart-x"></i> No disponible' : 
        '<i class="bi bi-cart-plus"></i> Agregar al Carrito';

    document.getElementById('productDetailPopup').style.display = 'block';
    document.getElementById('overlay').style.display = 'block';
}

function toggleWishlistPopup(productId) {
    toggleWishlist(productId);
    
    const wishlistBtn = document.getElementById('wishlistBtn');
    const isInWishlist = wishlist.some(item => item.productId === productId);
    
    wishlistBtn.innerHTML = isInWishlist ? 
        '<i class="bi bi-heart-fill"></i> En wishlist' : 
        '<i class="bi bi-heart"></i> Wishlist';
    
    wishlistBtn.className = isInWishlist ? 
        'btn btn-danger me-2' : 'btn btn-outline-danger me-2';
}

function addToCartPopup(productId) {
    addToCart(productId);
    
    const cartBtn = document.getElementById('cartBtn');
    const originalText = cartBtn.innerHTML;
    
    if (!cartBtn.disabled) {
        cartBtn.innerHTML = '<i class="bi bi-check-lg"></i> ¡Agregado!';
        cartBtn.disabled = true;
        
        setTimeout(() => {
            cartBtn.innerHTML = originalText;
            cartBtn.disabled = false;
        }, 2000);
    }
}

// =============================================
// FUNCIONES PARA VENDER PRODUCTOS CON STOCK
// =============================================

function showSellMessage(message, type = 'success') {
    const statusDiv = document.getElementById('sellStatusMessage');
    statusDiv.className = `alert alert-${type}`;
    statusDiv.innerHTML = message;
    statusDiv.style.display = 'block';
    
    if (type === 'success') {
        setTimeout(() => {
            statusDiv.style.display = 'none';
        }, 5000);
    }
}

function isValidURL(string) {
    try {
        new URL(string);
        return true;
    } catch (_) {
        return false;
    }
}

async function saveProductToAirtable(productData) {
    const productRecord = {
        fields: {
            "Nombre": productData.name,
            "Descripcion": productData.description,
            "Precio": parseFloat(productData.price),
            "Stock": parseInt(productData.stock),
            "Categoria": productData.category,
            "Status": productData.status,
            "ImagenUrl": productData.imageURL,
            "Fecha": new Date().toISOString().split('T')[0],
            "CreatedBy": productData.createdBy,
            "IsAvailable": productData.stock > 0
        }
    };

    try {
        const response = await fetch(`https://api.airtable.com/v0/${AIRTABLE_PRODUCTS_CONFIG.BASE_ID}/${AIRTABLE_PRODUCTS_CONFIG.TABLE_NAME}`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${AIRTABLE_PRODUCTS_CONFIG.ACCESS_TOKEN}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(productRecord)
        });

        if (response.ok) {
            const data = await response.json();
            return { success: true, data: data };
        } else {
            const errorText = await response.text();
            return { 
                success: false, 
                error: `Error ${response.status}: ${errorText}` 
            };
        }
    } catch (error) {
        return { 
            success: false, 
            error: `Error de conexión: ${error.message}` 
        };
    }
}

async function handleSellForm(event) {
    event.preventDefault();
    
    if (!authService.isAuthenticated()) {
        showSellMessage('❌ Debes iniciar sesión para vender productos', 'danger');
        return;
    }

    const user = authService.getCurrentUser();
    
    const productData = {
        name: document.getElementById('productName').value,
        description: document.getElementById('productDescription').value,
        price: document.getElementById('productPrice').value,
        stock: document.getElementById('productStock').value,
        category: document.getElementById('productCategory').value,
        status: document.getElementById('productStatus').value,
        imageURL: document.getElementById('productImageURL').value,
        createdBy: user.name
    };
    
    if (productData.price <= 0) {
        showSellMessage('❌ El precio debe ser mayor a 0', 'danger');
        return;
    }
    
    if (productData.stock < 1) {
        showSellMessage('❌ El stock debe ser al menos 1', 'danger');
        return;
    }
    
    if (!isValidURL(productData.imageURL)) {
        showSellMessage('❌ Ingresa una URL de imagen válida', 'danger');
        return;
    }
    
    if (!productData.category) {
        showSellMessage('❌ Selecciona una categoría', 'danger');
        return;
    }

    const submitButton = document.getElementById('submitButton');
    const originalText = submitButton.innerHTML;
    submitButton.innerHTML = '<i class="bi bi-hourglass-split me-2"></i>Publicando...';
    submitButton.disabled = true;

    showSellMessage('<i class="bi bi-hourglass-split me-2"></i>Publicando producto en la tienda...', 'info');

    const result = await saveProductToAirtable(productData);

    if (result.success) {
        showSellMessage(`
            ✅ ¡Producto publicado exitosamente!<br>
            <small>Actualizando la tienda...</small>
        `, 'success');
        
        // Limpiar formulario
        document.getElementById('sellForm').reset();
        document.getElementById('urlImagePreview').style.display = 'none';
        
        // Cerrar popup después de 1 segundo
        setTimeout(() => {
            closeSellPopup();
        }, 1000);
        
        // Recargar y actualizar la tienda automáticamente
        await refreshStore();
        
    } else {
        showSellMessage(`❌ Error al publicar producto: ${result.error}`, 'danger');
        submitButton.innerHTML = originalText;
        submitButton.disabled = false;
    }
}

// Función para actualizar la tienda después de publicar un producto
async function refreshStore() {
    try {
        console.log('🔄 Actualizando tienda después de publicar producto...');
        
        // Mostrar estado de carga
        const loadingState = document.getElementById('loadingState');
        const emptyState = document.getElementById('emptyState');
        const productsGrid = document.getElementById('productsGrid');
        
        if (loadingState && emptyState && productsGrid) {
            loadingState.style.display = 'block';
            emptyState.style.display = 'none';
            productsGrid.innerHTML = '';
        }
        
        // Recargar productos desde Airtable
        await loadProducts();
        
        // Re-renderizar productos
        renderProducts();
        
        console.log('✅ Tienda actualizada correctamente');
        
    } catch (error) {
        console.error('❌ Error actualizando tienda:', error);
        showSellMessage('❌ Error al actualizar la tienda', 'danger');
    }
}

function openSellPopup() {
    if (!authService.isAuthenticated()) {
        alert('⚠️ Debes iniciar sesión para vender productos');
        return;
    }
    
    const user = authService.getCurrentUser();
    document.getElementById('sellStatusMessage').innerHTML = `
        <small>Vendiendo como: <strong>${user.name}</strong></small>
    `;
    document.getElementById('sellStatusMessage').className = 'alert alert-info';
    document.getElementById('sellStatusMessage').style.display = 'block';
    
    document.getElementById('sellPopup').style.display = 'block';
    document.getElementById('overlay').style.display = 'block';
}

// =============================================
// FUNCIONES DE POPUP
// =============================================

function openWishlistPopup() {
    if (!authService.isAuthenticated()) {
        alert('Debes iniciar sesión para ver tu lista de deseos');
        return;
    }
    renderWishlist();
    document.getElementById('wishlistPopup').style.display = 'block';
    document.getElementById('overlay').style.display = 'block';
}

function closeWishlistPopup() {
    document.getElementById('wishlistPopup').style.display = 'none';
    document.getElementById('overlay').style.display = 'none';
}

function openCartPopup() {
    if (!authService.isAuthenticated()) {
        alert('Debes iniciar sesión para ver tu carrito');
        return;
    }
    renderCart();
    document.getElementById('cartPopup').style.display = 'block';
    document.getElementById('overlay').style.display = 'block';
}

function closeCartPopup() {
    document.getElementById('cartPopup').style.display = 'none';
    document.getElementById('overlay').style.display = 'none';
}

function closeSellPopup() {
    // Limpiar formulario
    const sellForm = document.getElementById('sellForm');
    if (sellForm) {
        sellForm.reset();
    }
    
    // Ocultar vista previa de imagen
    const urlImagePreview = document.getElementById('urlImagePreview');
    if (urlImagePreview) {
        urlImagePreview.style.display = 'none';
    }
    
    // Ocultar mensajes de estado
    const statusMessage = document.getElementById('sellStatusMessage');
    if (statusMessage) {
        statusMessage.style.display = 'none';
    }
    
    // Cerrar popup
    document.getElementById('sellPopup').style.display = 'none';
    document.getElementById('overlay').style.display = 'none';
}

function closeProductPopup() {
    document.getElementById('productDetailPopup').style.display = 'none';
    document.getElementById('overlay').style.display = 'none';
    currentProductId = null;
}

function closeAllPopups() {
    closeProductPopup();
    closeWishlistPopup();
    closeCartPopup();
    closeSellPopup();
}

// =============================================
// FILTROS Y BÚSQUEDA
// =============================================

function filterProducts() {
    const searchTerm = document.getElementById('searchInput').value.toLowerCase();
    const category = document.getElementById('categoryFilter').value;
    const productItems = document.querySelectorAll('.product-item');
    
    productItems.forEach(item => {
        const productName = item.getAttribute('data-name');
        const productCategory = item.getAttribute('data-category');
        
        const matchesSearch = productName.includes(searchTerm);
        const matchesCategory = category === 'all' || productCategory === category;
        
        item.style.display = (matchesSearch && matchesCategory) ? 'block' : 'none';
    });
}

function sortProducts() {
    const sortBy = document.getElementById('sortFilter').value;
    let sortedProducts = [...products];
    
    switch(sortBy) {
        case 'price-asc':
            sortedProducts.sort((a, b) => a.price - b.price);
            break;
        case 'price-desc':
            sortedProducts.sort((a, b) => b.price - a.price);
            break;
        case 'name':
            sortedProducts.sort((a, b) => a.name.localeCompare(b.name));
            break;
    }
    
    products = sortedProducts;
    renderProducts();
}

// =============================================
// UTILIDADES
// =============================================

function showErrorMessage(message) {
    console.error('❌ Error:', message);
    alert(message);
}

// Función para deshabilitar productos agotados
async function disableOutOfStockProducts() {
    try {
        const allProducts = await airtableService.getProducts();
        const outOfStockProducts = allProducts.filter(product => 
            product.stock <= 0 && product.isAvailable
        );
        
        for (const product of outOfStockProducts) {
            try {
                await updateProductStock(product.id, 0, false);
                console.log(`🔴 Producto deshabilitado: ${product.name}`);
            } catch (error) {
                console.error(`Error deshabilitando producto ${product.name}:`, error);
            }
        }
    } catch (error) {
        console.error('Error verificando productos agotados:', error);
    }
}

// Función para forzar recarga de productos (útil para debugging)
async function forceReloadProducts() {
    console.log('🔄 Forzando recarga de productos...');
    await loadProducts();
    renderProducts();
    
    // Mostrar notificación de actualización
    const productsGrid = document.getElementById('productsGrid');
    if (productsGrid) {
        const notification = document.createElement('div');
        notification.className = 'alert alert-info alert-dismissible fade show';
        notification.innerHTML = `
            ✅ Productos actualizados
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        productsGrid.parentNode.insertBefore(notification, productsGrid);
        
        // Auto-eliminar después de 3 segundos
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, 3000);
    }
}

document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape') {
        closeAllPopups();
    }
});

document.addEventListener('DOMContentLoaded', function() {
    const imageUrlInput = document.getElementById('productImageURL');
    if (imageUrlInput) {
        imageUrlInput.addEventListener('input', function() {
            const url = this.value;
            const preview = document.getElementById('urlPreview');
            const previewContainer = document.getElementById('urlImagePreview');
            
            if (url && isValidURL(url)) {
                preview.src = url;
                preview.onload = function() {
                    previewContainer.style.display = 'block';
                };
                preview.onerror = function() {
                    previewContainer.style.display = 'none';
                    showSellMessage('❌ No se pudo cargar la imagen desde esta URL', 'danger');
                };
            } else {
                previewContainer.style.display = 'none';
            }
        });
    }
});
// =============================================
// FUNCIONES PARA EL POPUP DE PERFIL
// =============================================

function openProfilePopup() {
    if (!authService.isAuthenticated()) {
        alert('Debes iniciar sesión para ver tu perfil');
        return;
    }
    
    loadProfileData();
    document.getElementById('profilePopup').style.display = 'block';
    document.getElementById('overlay').style.display = 'block';
}

function closeProfilePopup() {
    document.getElementById('profilePopup').style.display = 'none';
    document.getElementById('overlay').style.display = 'none';
}

async function loadProfileData() {
    try {
        const user = authService.getCurrentUser();
        
        // Actualizar información básica
        document.getElementById('profileUserName').textContent = user.name;
        document.getElementById('profileUserEmail').textContent = user.email;
        document.getElementById('profileMemberSince').textContent = new Date().toLocaleDateString('es-ES');
        
        // Actualizar contadores
        document.getElementById('profileWishlistCount').textContent = wishlist.length;
        document.getElementById('profileCartCount').textContent = cart.length;
        
        // Cargar historial de compras
        await loadProfilePurchaseHistory(user.id);
        
    } catch (error) {
        console.error('Error cargando datos del perfil:', error);
    }
}

async function loadProfilePurchaseHistory(userId) {
    try {
        const history = await airtableService.getUserPurchaseHistory(userId);
        
        // Ocultar loading
        document.getElementById('profileLoadingHistory').style.display = 'none';
        
        // Actualizar estadísticas
        document.getElementById('profileTotalPurchases').textContent = history.length;
        
        if (history.length === 0) {
            document.getElementById('profileEmptyHistory').style.display = 'block';
            document.getElementById('profileLastPurchase').textContent = 'No hay compras';
            return;
        }
        
        document.getElementById('profileRecentHistory').style.display = 'block';
        
        // Mostrar última compra
        const lastPurchase = history[0];
        const lastPurchaseDate = new Date(lastPurchase.fields.PurchaseDate).toLocaleDateString('es-ES');
        document.getElementById('profileLastPurchase').textContent = lastPurchaseDate;
        
        // Mostrar últimas 3 compras
        const recentPurchases = history.slice(0, 3);
        const recentHistoryContainer = document.querySelector('.purchase-history-list');
        recentHistoryContainer.innerHTML = recentPurchases.map(record => {
            const fields = record.fields;
            const total = fields.Quantity * fields.UnitPrice;
            
            return `
                <div class="recent-purchase-item mb-2 p-2 border rounded">
                    <div class="d-flex justify-content-between align-items-center">
                        <div class="purchase-info">
                            <strong class="d-block">${fields.ProductName}</strong>
                            <small class="text-muted">
                                ${fields.Quantity} x $${fields.UnitPrice} = $${total}
                            </small>
                        </div>
                        <small class="text-muted">
                            ${new Date(fields.PurchaseDate).toLocaleDateString('es-ES')}
                        </small>
                    </div>
                </div>
            `;
        }).join('');
        
    } catch (error) {
        console.error('Error cargando historial del perfil:', error);
        document.getElementById('profileLoadingHistory').innerHTML = `
            <div class="alert alert-danger py-2">
                <small>Error cargando historial</small>
            </div>
        `;
    }
}

function openFullProfile() {
    window.location.href = 'perfil.html';
}

// =============================================
// INICIALIZACIÓN
// =============================================

document.addEventListener('DOMContentLoaded', function() {
    authService.restoreSession();
    if (document.getElementById('productsGrid')) {
        initializeStore();
    }
});