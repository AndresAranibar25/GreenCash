// Main.js - Common functionality for GreenCash application
// Optimized and consolidated code

/**
 * Initialize application based on current page
 */
document.addEventListener('DOMContentLoaded', () => {
    // Restore authentication session
    if (typeof authService !== 'undefined') {
        authService.restoreSession();
        updateAuthUI();
    }
    
    // Initialize page-specific functionality
    initializePageFeatures();
});

/**
 * Update authentication UI across all pages
 */
function updateAuthUI() {
    const loginButton = document.getElementById('loginButton');
    const parentLi = document.getElementById('loginDropdownContainer') || loginButton?.parentElement;
    
    if (!loginButton || !parentLi) return;

    if (authService.isAuthenticated()) {
        const user = authService.getCurrentUser();
        setupAuthenticatedUI(loginButton, parentLi, user);
    } else {
        setupGuestUI(loginButton, parentLi);
    }
}

/**
 * Setup UI for authenticated users
 */
function setupAuthenticatedUI(loginButton, parentLi, user) {
    loginButton.innerHTML = `<i class="bi bi-person-circle me-1"></i>${user.name}`;
    loginButton.href = "#";
    loginButton.setAttribute('data-bs-toggle', 'dropdown');
    loginButton.classList.add('dropdown-toggle');
    
    // Ensure parent has dropdown class
    if (!parentLi.classList.contains('dropdown')) {
        parentLi.classList.add('dropdown');
    }
    
    // Create dropdown menu if not exists
    if (!loginButton.nextElementSibling?.classList.contains('dropdown-menu')) {
        const dropdownMenu = createDropdownMenu();
        parentLi.appendChild(dropdownMenu);
    }
}

/**
 * Setup UI for guest users
 */
function setupGuestUI(loginButton, parentLi) {
    loginButton.innerHTML = `<i class="bi bi-person-circle me-1"></i>Log in`;
    loginButton.href = "login.html";
    loginButton.removeAttribute('data-bs-toggle');
    loginButton.classList.remove('dropdown-toggle');
    
    const dropdownMenu = loginButton.nextElementSibling;
    if (dropdownMenu?.classList.contains('dropdown-menu')) {
        dropdownMenu.remove();
    }
}

/**
 * Create dropdown menu for authenticated users
 */
function createDropdownMenu() {
    const dropdownMenu = document.createElement('ul');
    dropdownMenu.className = 'dropdown-menu';
    dropdownMenu.innerHTML = `
        <li><a class="dropdown-item" href="#" onclick="openProfilePopup()">
            <i class="bi bi-person me-2"></i>Mi Perfil
        </a></li>
        <li><a class="dropdown-item" href="Tienda.html">
            <i class="bi bi-cart me-2"></i>Tienda
        </a></li>
        <li><hr class="dropdown-divider"></li>
        <li><a class="dropdown-item text-danger" href="#" onclick="authService.logout()">
            <i class="bi bi-box-arrow-right me-2"></i>Cerrar Sesión
        </a></li>
    `;
    return dropdownMenu;
}

/**
 * Initialize page-specific features
 */
function initializePageFeatures() {
    const currentPage = getCurrentPage();
    
    switch(currentPage) {
        case 'index':
            initSmoothScroll();
            break;
        case 'tienda':
            if (typeof initializeStore === 'function') {
                initializeStore();
            }
            break;
        case 'login':
            // Login page specific initialization if needed
            break;
    }
}

/**
 * Get current page name from URL
 */
function getCurrentPage() {
    const path = window.location.pathname;
    const page = path.split('/').pop().split('.')[0];
    return page || 'index';
}

/**
 * Initialize smooth scrolling for anchor links
 */
function initSmoothScroll() {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            if(targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if(targetElement) {
                window.scrollTo({ 
                    top: targetElement.offsetTop - 100, 
                    behavior: 'smooth' 
                });
            }
        });
    });
}

/**
 * Profile popup functions
 */
function openProfilePopup() {
    if (!authService.isAuthenticated()) {
        showAlert('Debes iniciar sesión para ver tu perfil', 'warning');
        return;
    }
    
    loadProfileData();
    showElement('profilePopup');
    showElement('overlay');
}

function closeProfilePopup() {
    hideElement('profilePopup');
    hideElement('overlay');
    removeElement('profileMessage');
}

/**
 * Load profile data
 */
async function loadProfileData() {
    try {
        const user = authService.getCurrentUser();
        
        // Update basic info
        updateElementText('profileUserName', user.name);
        updateElementText('profileUserEmail', user.email);
        updateElementText('profileMemberSince', new Date().toLocaleDateString('es-ES'));
        
        // Update counters
        const wishlistCount = typeof wishlist !== 'undefined' ? wishlist.length : '0';
        const cartCount = typeof cart !== 'undefined' ? cart.length : '0';
        
        updateElementText('profileWishlistCount', wishlistCount);
        updateElementText('profileCartCount', cartCount);
        
        // Load purchase history and user products
        await loadProfilePurchaseHistory(user.id);
        await loadUserProducts(user.name);
        
    } catch (error) {
        console.error('Error loading profile data:', error);
        showAlert('Error cargando datos del perfil', 'danger');
    }
}

/**
 * Load user purchase history
 */
async function loadProfilePurchaseHistory(userId) {
    try {
        showElement('profileLoadingHistory');
        hideElement('profileEmptyHistory');
        hideElement('profileRecentHistory');
        
        const history = await airtableService.getUserPurchaseHistory(userId);
        hideElement('profileLoadingHistory');
        
        updateElementText('profileTotalPurchases', history.length);
        
        if (history.length === 0) {
            showElement('profileEmptyHistory');
            updateElementText('profileLastPurchase', 'No hay compras');
            return;
        }
        
        showElement('profileRecentHistory');
        
        // Show last purchase
        const lastPurchase = history[0];
        const lastPurchaseDate = new Date(lastPurchase.fields.PurchaseDate).toLocaleDateString('es-ES');
        updateElementText('profileLastPurchase', `${lastPurchase.fields.ProductName} - ${lastPurchaseDate}`);
        
        // Render recent purchases
        renderRecentPurchases(history.slice(0, 3), history.length);
        
    } catch (error) {
        console.error('Error loading purchase history:', error);
        const loadingElement = document.getElementById('profileLoadingHistory');
        if (loadingElement) {
            loadingElement.style.display = 'none';
            loadingElement.innerHTML = `<div class="alert alert-danger"><i class="bi bi-exclamation-triangle"></i>Error cargando historial</div>`;
        }
    }
}

/**
 * Render recent purchases
 */
function renderRecentPurchases(recentPurchases, totalCount) {
    const historyContainer = document.getElementById('purchaseHistoryList');
    if (!historyContainer) return;
    
    historyContainer.innerHTML = recentPurchases.map(record => {
        const fields = record.fields;
        const total = fields.Quantity * fields.UnitPrice;
        const purchaseDate = new Date(fields.PurchaseDate).toLocaleDateString('es-ES');
        
        return `
            <div class="purchase-history-item mb-3 p-3 border rounded">
                <div class="row align-items-center">
                    <div class="col-md-7">
                        <div class="purchase-product-info">
                            <h6 class="mb-1 text-primary">${fields.ProductName}</h6>
                            <small class="text-muted">Orden: ${fields.OrderID}</small>
                        </div>
                    </div>
                    <div class="col-md-3 text-center">
                        <span class="badge bg-light text-dark fs-6">${fields.Quantity} und</span>
                    </div>
                    <div class="col-md-2 text-end">
                        <div class="purchase-total">
                            <strong class="text-success fs-5">$${total.toLocaleString()}</strong>
                            <div class="mt-1"><small class="text-muted">${purchaseDate}</small></div>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }).join('');
    
    if (totalCount > 3) {
        historyContainer.innerHTML += `<div class="text-center mt-2"><small class="text-muted">Y ${totalCount - 3} compras más...</small></div>`;
    }
}

/**
 * Load user products
 */
async function loadUserProducts(userName) {
    try {
        showElement('userProductsLoading');
        hideElement('userProductsEmpty');
        hideElement('userProductsList');
        
        const allProducts = await airtableService.getProducts();
        const userProducts = allProducts.filter(product => 
            product.createdBy === userName && product.isAvailable
        );
        
        hideElement('userProductsLoading');
        
        if (userProducts.length === 0) {
            showElement('userProductsEmpty');
            return;
        }
        
        showElement('userProductsList');
        renderUserProducts(userProducts);
        
    } catch (error) {
        console.error('Error loading user products:', error);
        const loadingElement = document.getElementById('userProductsLoading');
        if (loadingElement) {
            loadingElement.style.display = 'none';
            loadingElement.innerHTML = `<div class="alert alert-danger"><i class="bi bi-exclamation-triangle"></i>Error cargando productos</div>`;
        }
    }
}

/**
 * Render user products
 */
function renderUserProducts(userProducts) {
    const productsContainer = document.getElementById('userProductsGrid');
    if (!productsContainer) return;
    
    productsContainer.innerHTML = userProducts.map(product => `
        <div class="user-product-card" data-product-id="${product.id}">
            <div class="user-product-image-container">
                <img src="${product.image}" alt="${product.name}" class="user-product-image"
                    onerror="this.src='https://via.placeholder.com/200x150/4CAF50/FFFFFF?text=Imagen+No+Disponible'">
                <div class="user-product-overlay">
                    <span class="user-product-status ${product.stock > 0 ? 'in-stock' : 'out-of-stock'}">
                        ${product.stock > 0 ? `${product.stock} disponibles` : 'Agotado'}
                    </span>
                </div>
                <button class="user-product-delete-btn" onclick="confirmDeleteProduct('${product.id}', '${product.name}')" title="Eliminar producto">
                    <i class="bi bi-trash"></i>
                </button>
            </div>
            <div class="user-product-info">
                <div class="user-product-category">${product.category}</div>
                <h6 class="user-product-name">${product.name}</h6>
                <p class="user-product-description">${product.description?.substring(0, 80)}${product.description?.length > 80 ? '...' : ''}</p>
                <div class="user-product-footer">
                    <span class="user-product-price">$${product.price?.toLocaleString() || '0'}</span>
                    <div class="user-product-demo-badges">
                        <span class="badge bg-secondary">Vista previa</span>
                        <span class="badge bg-light text-dark">En venta</span>
                    </div>
                </div>
            </div>
        </div>
    `).join('');
}

/**
 * Confirm and delete product
 */
function confirmDeleteProduct(productId, productName) {
    if (confirm(`¿Estás seguro de que quieres eliminar "${productName}"?\n\nEsta acción no se puede deshacer.`)) {
        deleteUserProduct(productId);
    }
}

/**
 * Delete user product
 */
async function deleteUserProduct(productId) {
    try {
        const productCard = document.querySelector(`[data-product-id="${productId}"]`);
        if (productCard) {
            productCard.style.opacity = '0.6';
            productCard.style.pointerEvents = 'none';
        }
        
        const success = await airtableService.deleteProduct(productId);
        if (success) {
            showProfileMessage('✅ Producto eliminado exitosamente', 'success');
            
            if (productCard) {
                productCard.style.transition = 'all 0.3s ease';
                productCard.style.transform = 'scale(0.8)';
                productCard.style.opacity = '0';
                setTimeout(() => productCard.remove(), 300);
            }
            
            // Reload user products
            const user = authService.getCurrentUser();
            await loadUserProducts(user.name);
            
            // Refresh store if available
            if (typeof initializeStore === 'function') {
                await initializeStore();
            }
        } else {
            throw new Error('No se pudo eliminar el producto');
        }
    } catch (error) {
        console.error('Error deleting product:', error);
        showProfileMessage('❌ Error al eliminar el producto', 'danger');
        
        const productCard = document.querySelector(`[data-product-id="${productId}"]`);
        if (productCard) {
            productCard.style.opacity = '1';
            productCard.style.pointerEvents = 'auto';
            productCard.style.transform = 'scale(1)';
        }
    }
}

/**
 * Show profile message
 */
function showProfileMessage(message, type = 'success') {
    let messageDiv = document.getElementById('profileMessage');
    if (!messageDiv) {
        messageDiv = document.createElement('div');
        messageDiv.id = 'profileMessage';
        messageDiv.className = `alert alert-${type} alert-dismissible fade show`;
        
        const popupBody = document.querySelector('#profilePopup .popup-body');
        if (popupBody) {
            popupBody.insertBefore(messageDiv, popupBody.firstChild);
        }
    } else {
        messageDiv.className = `alert alert-${type} alert-dismissible fade show`;
    }
    
    messageDiv.innerHTML = `${message}<button type="button" class="btn-close" data-bs-dismiss="alert"></button>`;
    
    // Auto-remove after 5 seconds
    setTimeout(() => {
        if (messageDiv?.parentNode) {
            messageDiv.remove();
        }
    }, 5000);
}

// =============================================
// UTILITY FUNCTIONS
// =============================================

/**
 * Show element by ID
 */
function showElement(elementId) {
    const element = document.getElementById(elementId);
    if (element) {
        element.style.display = 'block';
    }
}

/**
 * Hide element by ID
 */
function hideElement(elementId) {
    const element = document.getElementById(elementId);
    if (element) {
        element.style.display = 'none';
    }
}

/**
 * Update element text content
 */
function updateElementText(elementId, text) {
    const element = document.getElementById(elementId);
    if (element) {
        element.textContent = text;
    }
}

/**
 * Remove element by ID
 */
function removeElement(elementId) {
    const element = document.getElementById(elementId);
    if (element && element.parentNode) {
        element.remove();
    }
}

/**
 * Show alert message
 */
function showAlert(message, type = 'info') {
    // Use browser alert for now, can be enhanced with custom modal
    const icons = {
        'success': '✅',
        'danger': '❌',
        'warning': '⚠️',
        'info': 'ℹ️'
    };
    
    alert(`${icons[type] || icons.info} ${message}`);
}

/**
 * Debounce function for performance
 */
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

/**
 * Throttle function for performance
 */
function throttle(func, limit) {
    let inThrottle;
    return function() {
        const args = arguments;
        const context = this;
        if (!inThrottle) {
            func.apply(context, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}