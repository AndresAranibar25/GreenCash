// Configuración de Airtable
const AIRTABLE_CONFIG = {
    ACCESS_TOKEN: 'patgXXuC5Cc2fOXLX.f742cfd9463aeb945440e76b471c59114e54ac1e3c42fb5300d76ab026daf7bd',
    BASE_ID: 'appovrtUpixz5DBRW',
    TABLES: {
        USERS: 'Users',
        PRODUCTS: 'Productos',
        WISHLIST: 'Wishlist',  
        CART: 'Carrito'
    }
};

// Estado global
let currentUser = null;
let authToken = null;

class AirtableService {
    constructor() {
        this.baseURL = `https://api.airtable.com/v0/${AIRTABLE_CONFIG.BASE_ID}`;
        this.headers = {
            'Authorization': `Bearer ${AIRTABLE_CONFIG.ACCESS_TOKEN}`,
            'Content-Type': 'application/json'
        };
    }

    async makeRequest(endpoint, options = {}) {
        try {
            console.log(`🔗 Haciendo petición a: ${this.baseURL}/${endpoint}`);
            
            const response = await fetch(`${this.baseURL}/${endpoint}`, {
                headers: this.headers,
                ...options
            });
            
            console.log(`📊 Respuesta: ${response.status} ${response.statusText}`);
            
            if (!response.ok) {
                if (response.status === 401) {
                    throw new Error('Token de acceso inválido.');
                } else if (response.status === 403) {
                    throw new Error('No tienes permisos.');
                } else if (response.status === 404) {
                    throw new Error('Base o tabla no encontrada.');
                }
                throw new Error(`Error ${response.status}: ${response.statusText}`);
            }
            
            const data = await response.json();
            console.log(`✅ Petición exitosa. Registros: ${data.records ? data.records.length : 'N/A'}`);
            return data;
            
        } catch (error) {
            console.error('❌ Error en petición Airtable:', error);
            throw error;
        }
    }

    // Users - BUSCAR USUARIO POR EMAIL
    async getUserByEmail(email) {
        console.log(`🔍 Buscando usuario: ${email}`);
        const filter = `{Email} = "${email}"`;
        const response = await this.makeRequest(`${AIRTABLE_CONFIG.TABLES.USERS}?filterByFormula=${encodeURIComponent(filter)}`);
        return response.records[0] || null;
    }

    // CREAR USUARIO (sin DateCreated e IsActive)
    async createUser(userData) {
        console.log(`👤 Creando usuario: ${userData.email}`);
        return await this.makeRequest(AIRTABLE_CONFIG.TABLES.USERS, {
            method: 'POST',
            body: JSON.stringify({
                fields: {
                    Name: userData.name,
                    Email: userData.email,
                    Password: userData.password
                    // DateCreated e IsActive comentados
                }
            })
        });
    }

    // ACTUALIZAR USUARIO (para poner IsActive en true)
    async updateUser(userId, updates) {
        console.log(`🔄 Actualizando usuario: ${userId}`);
        return await this.makeRequest(`${AIRTABLE_CONFIG.TABLES.USERS}/${userId}`, {
            method: 'PATCH',
            body: JSON.stringify({
                fields: updates
            })
        });
    }
    // En AirtableService class - Agregar estos métodos:

    // Wishlist methods
    async removeFromWishlist(recordId) {
        return await this.makeRequest(`${AIRTABLE_CONFIG.TABLES.WISHLIST}/${recordId}`, {
            method: 'DELETE'
        });
    }

    // Cart methods
    async updateCartItem(recordId, quantity) {
        return await this.makeRequest(`${AIRTABLE_CONFIG.TABLES.CART}/${recordId}`, {
            method: 'PATCH',
            body: JSON.stringify({
                fields: {
                    Quantity: quantity
                }
            })
        });
    }

    async removeFromCart(recordId) {
        return await this.makeRequest(`${AIRTABLE_CONFIG.TABLES.CART}/${recordId}`, {
            method: 'DELETE'
        });
    }

    // Product methods
    async updateProductStatus(productId, status) {
        return await this.makeRequest(`${AIRTABLE_CONFIG.TABLES.PRODUCTS}/${productId}`, {
            method: 'PATCH',
            body: JSON.stringify({
                fields: {
                    Status: status,
                    IsAvailable: status === 'available'
                }
            })
        });
    }
    // Wishlist methods mejorados
    async getUserWishlist(userId) {
        console.log(`💖 Obteniendo wishlist para usuario: ${userId}`);
        const filter = `{UserID} = "${userId}"`;
        const response = await this.makeRequest(`${AIRTABLE_CONFIG.TABLES.WISHLIST}?filterByFormula=${encodeURIComponent(filter)}`);
        return response.records;
    }

    async addToWishlist(userId, productId) {
        console.log(`➕ Agregando a wishlist - Usuario: ${userId}, Producto: ${productId}`);
        return await this.makeRequest(AIRTABLE_CONFIG.TABLES.WISHLIST, {
            method: 'POST',
            body: JSON.stringify({
                fields: {
                    UserID: userId, // CAMBIADO: Sin corchetes
                    ProductID: productId, // CAMBIADO: Sin corchetes
                    IsSelected: false,
                    DateAdded: new Date().toISOString().split('T')[0]
                }
            })
        });
    }

    async removeFromWishlist(recordId) {
        console.log(`🗑️ Eliminando de wishlist: ${recordId}`);
        return await this.makeRequest(`${AIRTABLE_CONFIG.TABLES.WISHLIST}/${recordId}`, {
            method: 'DELETE'
        });
    }

    // Cart methods mejorados
    async getUserCart(userId) {
        console.log(`🛒 Obteniendo carrito para usuario: ${userId}`);
        const filter = `{UserID} = "${userId}"`;
        const response = await this.makeRequest(`${AIRTABLE_CONFIG.TABLES.CART}?filterByFormula=${encodeURIComponent(filter)}`);
        return response.records;
    }

    async addToCart(userId, productId, quantity = 1) {
        console.log(`➕ Agregando al carrito - Usuario: ${userId}, Producto: ${productId}, Cantidad: ${quantity}`);
        return await this.makeRequest(AIRTABLE_CONFIG.TABLES.CART, {
            method: 'POST',
            body: JSON.stringify({
                fields: {
                    UserID: userId, // CAMBIADO: Sin corchetes
                    ProductID: productId, // CAMBIADO: Sin corchetes
                    Quantity: quantity,
                    DateAdded: new Date().toISOString().split('T')[0]
                }
            })
        });
    }

    async updateCartItem(recordId, quantity) {
        console.log(`✏️ Actualizando carrito: ${recordId}, Cantidad: ${quantity}`);
        return await this.makeRequest(`${AIRTABLE_CONFIG.TABLES.CART}/${recordId}`, {
            method: 'PATCH',
            body: JSON.stringify({
                fields: {
                    Quantity: quantity
                }
            })
        });
    }

    async removeFromCart(recordId) {
        console.log(`🗑️ Eliminando del carrito: ${recordId}`);
        return await this.makeRequest(`${AIRTABLE_CONFIG.TABLES.CART}/${recordId}`, {
            method: 'DELETE'
        });
    }

    // Product methods
    async updateProductStatus(productId, status) {
        console.log(`🔄 Actualizando producto: ${productId}, Status: ${status}`);
        return await this.makeRequest(`${AIRTABLE_CONFIG.TABLES.PRODUCTS}/${productId}`, {
            method: 'PATCH',
            body: JSON.stringify({
                fields: {
                    Status: status,
                    IsAvailable: status === 'available'
                }
            })
        });
    }

 // Products
// EN auth.js - REEMPLAZA la función getProducts con esta versión:
async getProducts() {
    console.log('📦 Solicitando productos desde Airtable...');
    
    try {
        const response = await this.makeRequest(`${AIRTABLE_CONFIG.TABLES.PRODUCTS}?view=Grid%20view`);
        
        if (!response.records || response.records.length === 0) {
            return [];
        }
        
        const products = response.records.map(record => {
            return {
                id: record.id,
                name: record.fields.Nombre || 'Sin nombre',
                description: record.fields.Descripcion || 'Sin descripción',
                price: record.fields.Precio || 0,
                category: record.fields.Categoria || 'general',
                image: record.fields.ImagenURL || record.fields.ImagenUrl || 'https://via.placeholder.com/300x200/4CAF50/FFFFFF?text=Imagen+No+Disponible',
                isAvailable: record.fields.IsAvailable !== false,
                status: record.fields.Status || 'available',
                createdBy: record.fields.CreatedBy || 'Anónimo' // NUEVO CAMPO AGREGADO
            };
        });
        
        return products;
        
    } catch (error) {
        console.error('❌ Error en getProducts:', error);
        throw error;
    }
}
    // Wishlist
    async getUserWishlist(userId) {
        console.log(`💖 Obteniendo wishlist para usuario: ${userId}`);
        const filter = `{UserID} = "${userId}"`;
        const response = await this.makeRequest(`${AIRTABLE_CONFIG.TABLES.WISHLIST}?filterByFormula=${encodeURIComponent(filter)}`);
        return response.records.map(record => record.fields.ProductID[0]);
    }

    async addToWishlist(userId, productId) {
        console.log(`➕ Agregando a wishlist - Usuario: ${userId}, Producto: ${productId}`);
        return await this.makeRequest(AIRTABLE_CONFIG.TABLES.WISHLIST, {
            method: 'POST',
            body: JSON.stringify({
                fields: {
                    UserID: [userId],
                    ProductID: [productId]
                }
            })
        });
    }

    // Cart
    async getUserCart(userId) {
        console.log(`🛒 Obteniendo carrito para usuario: ${userId}`);
        const filter = `{UserID} = "${userId}"`;
        const response = await this.makeRequest(`${AIRTABLE_CONFIG.TABLES.CART}?filterByFormula=${encodeURIComponent(filter)}`);
        return response.records.map(record => ({
            recordId: record.id,
            productId: record.fields.ProductID[0],
            quantity: record.fields.Quantity || 1
        }));
    }

    async addToCart(userId, productId, quantity = 1) {
        console.log(`➕ Agregando al carrito - Usuario: ${userId}, Producto: ${productId}`);
        return await this.makeRequest(AIRTABLE_CONFIG.TABLES.CART, {
            method: 'POST',
            body: JSON.stringify({
                fields: {
                    UserID: [userId],
                    ProductID: [productId],
                    Quantity: quantity
                }
            })
        });
    }
}

class AuthService {
    constructor() {
        this.airtable = new AirtableService();
    }

    async login(email, password) {
        console.log(`🔐 Intentando login: ${email}`);
        const user = await this.airtable.getUserByEmail(email);
        
        if (!user) {
            throw new Error('Usuario no encontrado');
        }

        if (user.fields.Password !== password) {
            throw new Error('Contraseña incorrecta');
        }

        // Si el usuario tiene campo IsActive, verificarlo
        if (user.fields.IsActive === false) {
            throw new Error('Cuenta desactivada');
        }

        // Si no tiene IsActive, lo creamos automáticamente
        if (user.fields.IsActive === undefined) {
            console.log('🔄 Usuario sin IsActive, actualizando...');
            await this.airtable.updateUser(user.id, { IsActive: true });
        }

        // Crear token de sesión
        const token = btoa(JSON.stringify({
            userId: user.id,
            email: user.fields.Email,
            name: user.fields.Name,
            exp: Date.now() + (24 * 60 * 60 * 1000) // 24 horas
        }));

        this.setAuthToken(token);
        this.setCurrentUser({
            id: user.id,
            name: user.fields.Name,
            email: user.fields.Email
        });

        console.log(`✅ Login exitoso: ${user.fields.Name}`);
        return user;
    }

    async register(name, email, password) {
        console.log(`📝 Registrando nuevo usuario: ${email}`);
        const existingUser = await this.airtable.getUserByEmail(email);
        if (existingUser) {
            throw new Error('El email ya está registrado');
        }

        const newUser = await this.airtable.createUser({ name, email, password });
        console.log(`✅ Usuario registrado: ${name}`);
        
        // Hacer login automático después del registro
        return this.login(email, password);
    }

    // CERRAR SESIÓN
    logout() {
        console.log('🚪 Cerrando sesión...');
        this.clearAuthToken();
        this.setCurrentUser(null);
        // Redirigir al login
        window.location.href = 'login.html';
    }

    setAuthToken(token) {
        localStorage.setItem('authToken', token);
        authToken = token;
    }

    getAuthToken() {
        return localStorage.getItem('authToken');
    }

    clearAuthToken() {
        localStorage.removeItem('authToken');
        localStorage.removeItem('currentUser'); // Limpiar también el usuario
        authToken = null;
        currentUser = null;
    }

    setCurrentUser(user) {
        currentUser = user;
        if (user) {
            localStorage.setItem('currentUser', JSON.stringify(user));
        } else {
            localStorage.removeItem('currentUser');
        }
    }

    getCurrentUser() {
        if (currentUser) return currentUser;
        
        const storedUser = localStorage.getItem('currentUser');
        if (storedUser) {
            try {
                currentUser = JSON.parse(storedUser);
                return currentUser;
            } catch {
                return null;
            }
        }
        
        return null;
    }

    isAuthenticated() {
        const token = this.getAuthToken();
        if (!token) return false;

        try {
            const tokenData = JSON.parse(atob(token));
            // Verificar que el token no haya expirado
            return tokenData.exp > Date.now();
        } catch {
            return false;
        }
    }

    restoreSession() {
        if (this.isAuthenticated()) {
            const token = this.getAuthToken();
            try {
                const tokenData = JSON.parse(atob(token));
                this.setCurrentUser({
                    id: tokenData.userId,
                    name: tokenData.name,
                    email: tokenData.email
                });
                return true;
            } catch {
                this.clearAuthToken();
                return false;
            }
        }
        return false;
    }
}

// Instancias globales
const authService = new AuthService();
const airtableService = new AirtableService();