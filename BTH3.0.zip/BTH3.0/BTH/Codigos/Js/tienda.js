// Estado de la tienda
let products = [];
let wishlist = [];
let cart = [];
let currentProductId = null;

// Configuración de Airtable para productos
const AIRTABLE_PRODUCTS_CONFIG = {
    ACCESS_TOKEN: 'patgXXuC5Cc2fOXLX.f742cfd9463aeb945440e76b471c59114e54ac1e3c42fb5300d76ab026daf7bd',  // ← USA EL MISMO TOKEN
    BASE_ID: 'appovrtUpixz5DBRW',            // ← USA EL MISMO BASE ID  
    TABLE_NAME: 'Productos'
};

// Inicializar tienda - VERSIÓN CORREGIDA
async function initializeStore() {
    console.log('🏪 Inicializando tienda...');
    
    try {
        await loadProducts();
        console.log('📦 Productos cargados:', products.length);
        
        await loadUserData();
        console.log('👤 Datos de usuario cargados');
        
        renderProducts();
        console.log('🎨 Productos renderizados');
        
        updateHeader();
        console.log('🔤 Header actualizado');
        
    } catch (error) {
        console.error('❌ Error inicializando tienda:', error);
        showErrorMessage('Error cargando la tienda. Recarga la página.');
    }
}

// Cargar productos desde Airtable
async function loadProducts() {
    try {
        console.log('📦 Cargando productos desde Airtable...');
        products = await airtableService.getProducts();
        console.log(`✅ ${products.length} productos cargados`);
        
        // Filtrar solo productos disponibles
        products = products.filter(product => 
            product.isAvailable && product.status !== 'sold'
        );
        
    } catch (error) {
        console.error('❌ Error cargando productos:', error);
        products = [];
        showErrorMessage('Error cargando productos. Intenta recargar la página.');
    }
}

// Cargar datos del usuario - VERSIÓN CORREGIDA
async function loadUserData() {
    if (authService.isAuthenticated()) {
        const userId = authService.getCurrentUser().id;
        try {
            console.log('👤 Cargando datos del usuario...');
            
            // Cargar wishlist
            const wishlistData = await airtableService.getUserWishlist(userId);
            console.log('💖 Wishlist data:', wishlistData);
            wishlist = wishlistData.map(record => ({
                recordId: record.id,
                productId: record.fields.ProductID,
                isSelected: record.fields.IsSelected || false
            }));
            console.log('💖 Wishlist procesada:', wishlist);
            
            // Cargar carrito
            const cartData = await airtableService.getUserCart(userId);
            console.log('🛒 Cart data:', cartData);
            cart = cartData.map(record => ({
                recordId: record.id,
                productId: record.fields.ProductID,
                quantity: record.fields.Quantity || 1
            }));
            console.log('🛒 Carrito procesado:', cart);
            
        } catch (error) {
            console.error('❌ Error cargando datos usuario:', error);
        }
    } else {
        console.log('👤 Usuario no autenticado, no se cargan datos');
    }
}

// Renderizar productos - VERSIÓN SIN STOCK
function renderProducts() {
    const productsGrid = document.getElementById('productsGrid');
    const loadingState = document.getElementById('loadingState');
    const emptyState = document.getElementById('emptyState');

    if (!productsGrid) return;

    // Ocultar estado de carga
    if (loadingState) loadingState.style.display = 'none';

    if (products.length === 0) {
        // Mostrar estado vacío
        if (emptyState) emptyState.style.display = 'block';
        productsGrid.innerHTML = '';
        return;
    }

    // Ocultar estado vacío
    if (emptyState) emptyState.style.display = 'none';

    // Renderizar productos SIN STOCK
    productsGrid.innerHTML = products.map(product => `
        <div class="col-lg-3 col-md-4 col-sm-6 product-item" 
             data-category="${product.category}" 
             data-name="${product.name.toLowerCase()}"
             onclick="openProductPopup('${product.id}')">
            <div class="card product-card h-100">
                <img src="${product.image}" class="card-img-top product-image" alt="${product.name}"
                     onerror="this.src='https://via.placeholder.com/300x200/4CAF50/FFFFFF?text=Imagen+No+Disponible'">
                <div class="card-body d-flex flex-column">
                    <span class="product-category">${product.category?.charAt(0)?.toUpperCase() + product.category?.slice(1) || 'Sin categoría'}</span>
                    <h5 class="card-title mt-2 flex-grow-1">${product.name}</h5>
                    <div class="mt-auto">
                        <div class="d-flex justify-content-between align-items-center">
                            <span class="product-price">$${product.price?.toLocaleString() || '0'}</span>
                            <div class="product-actions">
                                <button class="btn-wishlist" onclick="toggleWishlist('${product.id}', event)">
                                    <i class="bi bi-heart${wishlist.some(item => item.productId === product.id) ? '-fill text-danger' : ''}"></i>
                                </button>
                                <button class="btn-cart" onclick="addToCart('${product.id}', 1, event)" 
                                        ${!product.isAvailable ? 'disabled' : ''}>
                                    <i class="bi bi-cart-plus"></i>
                                </button>
                            </div>
                        </div>
                        ${!product.isAvailable ? '<div class="mt-2"><span class="badge bg-warning">Agotado</span></div>' : ''}
                    </div>
                </div>
            </div>
        </div>
    `).join('');
}

// Wishlist functions - VERSIÓN CORREGIDA
async function toggleWishlist(productId, event = null) {
    if (event) event.stopPropagation();
    
    if (!authService.isAuthenticated()) {
        alert('Debes iniciar sesión para usar la lista de deseos');
        return;
    }

    const userId = authService.getCurrentUser().id;
    
    try {
        // Verificar si ya está en wishlist
        const existingItem = wishlist.find(item => item.productId === productId);
        
        if (existingItem) {
            // Remover de wishlist
            console.log('🗑️ Removiendo de wishlist:', productId);
            await airtableService.removeFromWishlist(existingItem.recordId);
            wishlist = wishlist.filter(item => item.productId !== productId);
            alert('❌ Eliminado de la lista de deseos');
        } else {
            // Agregar a wishlist
            console.log('➕ Agregando a wishlist:', productId);
            const result = await airtableService.addToWishlist(userId, productId);
            wishlist.push({
                recordId: result.id,
                productId: productId,
                isSelected: false
            });
            alert('✅ Agregado a la lista de deseos');
        }
        
        // Actualizar UI
        renderProducts();
        if (document.getElementById('wishlistPopup').style.display === 'block') {
            renderWishlist();
        }
        
    } catch (error) {
        console.error('❌ Error actualizando wishlist:', error);
        alert('Error al actualizar la lista de deseos');
    }
}

// Renderizar wishlist
function renderWishlist() {
    const wishlistBody = document.getElementById('wishlistBody');
    const wishlistEmpty = document.getElementById('wishlistEmpty');
    const wishlistContent = document.getElementById('wishlistContent');
    
    if (wishlist.length === 0) {
        wishlistEmpty.style.display = 'block';
        wishlistContent.style.display = 'none';
        return;
    }
    
    wishlistEmpty.style.display = 'none';
    wishlistContent.style.display = 'block';
    
    wishlistBody.innerHTML = wishlist.map(item => {
        const product = products.find(p => p.id === item.productId);
        if (!product) return '';
        
        return `
            <div class="wishlist-item ${item.isSelected ? 'selected' : ''}">
                <div class="form-check">
                    <input class="form-check-input wishlist-checkbox" type="checkbox" 
                           ${item.isSelected ? 'checked' : ''} 
                           onchange="toggleWishlistSelection('${item.recordId}')">
                </div>
                <img src="${product.image}" alt="${product.name}" class="wishlist-image">
                <div class="wishlist-info">
                    <h6 class="wishlist-name">${product.name}</h6>
                    <span class="wishlist-price">$${product.price?.toLocaleString() || '0'}</span>
                </div>
                <button class="btn btn-sm btn-outline-danger" onclick="removeFromWishlist('${item.recordId}')">
                    <i class="bi bi-trash"></i>
                </button>
            </div>
        `;
    }).join('');
    
    updateWishlistActions();
}

// Seleccionar/deseleccionar item de wishlist
function toggleWishlistSelection(recordId) {
    const item = wishlist.find(item => item.recordId === recordId);
    if (item) {
        item.isSelected = !item.isSelected;
        renderWishlist();
    }
}

// Seleccionar todos los items
function selectAllWishlist() {
    const allSelected = wishlist.every(item => item.isSelected);
    wishlist.forEach(item => {
        item.isSelected = !allSelected;
    });
    renderWishlist();
}

// Eliminar item de wishlist
async function removeFromWishlist(recordId) {
    try {
        await airtableService.removeFromWishlist(recordId);
        wishlist = wishlist.filter(item => item.recordId !== recordId);
        renderWishlist();
        renderProducts();
    } catch (error) {
        console.error('Error eliminando de wishlist:', error);
    }
}

// Eliminar todos los items de wishlist
async function clearWishlist() {
    if (!confirm('¿Estás seguro de que quieres eliminar todos los items de tu lista de deseos?')) {
        return;
    }
    
    try {
        for (const item of wishlist) {
            await airtableService.removeFromWishlist(item.recordId);
        }
        wishlist = [];
        renderWishlist();
        renderProducts();
    } catch (error) {
        console.error('Error limpiando wishlist:', error);
    }
}

// Agregar seleccionados al carrito
async function addSelectedToCart() {
    const selectedItems = wishlist.filter(item => item.isSelected);
    
    if (selectedItems.length === 0) {
        alert('Selecciona al menos un producto para agregar al carrito');
        return;
    }
    
    const userId = authService.getCurrentUser().id;
    let addedCount = 0;
    
    for (const item of selectedItems) {
        try {
            await airtableService.addToCart(userId, item.productId);
            addedCount++;
        } catch (error) {
            console.error(`Error agregando producto ${item.productId} al carrito:`, error);
        }
    }
    
    alert(`✅ ${addedCount} producto(s) agregado(s) al carrito`);
    closeWishlistPopup();
}

// Actualizar acciones de wishlist
function updateWishlistActions() {
    const selectedCount = wishlist.filter(item => item.isSelected).length;
    const selectAllBtn = document.getElementById('selectAllWishlist');
    const addToCartBtn = document.getElementById('addSelectedToCart');
    const clearAllBtn = document.getElementById('clearWishlist');
    
    if (selectAllBtn) {
        selectAllBtn.textContent = wishlist.every(item => item.isSelected) ? 
            'Deseleccionar Todos' : 'Seleccionar Todos';
    }
    
    if (addToCartBtn) {
        addToCartBtn.disabled = selectedCount === 0;
        addToCartBtn.innerHTML = selectedCount > 0 ? 
            `<i class="bi bi-cart-plus"></i> Agregar (${selectedCount}) al Carrito` :
            `<i class="bi bi-cart-plus"></i> Agregar al Carrito`;
    }
    
    if (clearAllBtn) {
        clearAllBtn.disabled = wishlist.length === 0;
    }
}

// Cart functions - VERSIÓN CORREGIDA
async function addToCart(productId, quantity = 1, event = null) {
    if (event) event.stopPropagation();
    
    if (!authService.isAuthenticated()) {
        alert('Debes iniciar sesión para agregar al carrito');
        return;
    }

    const product = products.find(p => p.id === productId);
    if (!product || !product.isAvailable) {
        alert('❌ Este producto no está disponible');
        return;
    }

    const userId = authService.getCurrentUser().id;
    
    try {
        console.log('🛒 Agregando al carrito:', productId);
        
        // Verificar si ya está en el carrito
        const existingItem = cart.find(item => item.productId === productId);
        
        if (existingItem) {
            // Actualizar cantidad
            await airtableService.updateCartItem(existingItem.recordId, existingItem.quantity + quantity);
            existingItem.quantity += quantity;
        } else {
            // Agregar nuevo item
            const result = await airtableService.addToCart(userId, productId, quantity);
            cart.push({
                recordId: result.id,
                productId: productId,
                quantity: quantity
            });
        }
        
        alert('✅ Producto agregado al carrito');
        
        // Actualizar UI del carrito si está abierto
        if (document.getElementById('cartPopup').style.display === 'block') {
            renderCart();
        }
        
    } catch (error) {
        console.error('❌ Error agregando al carrito:', error);
        alert('❌ Error al agregar al carrito. Verifica la consola para más detalles.');
    }
}

// Renderizar carrito
function renderCart() {
    const cartBody = document.getElementById('cartBody');
    const cartEmpty = document.getElementById('cartEmpty');
    const cartContent = document.getElementById('cartContent');
    const cartTotal = document.getElementById('cartTotal');
    
    if (cart.length === 0) {
        cartEmpty.style.display = 'block';
        cartContent.style.display = 'none';
        return;
    }
    
    cartEmpty.style.display = 'none';
    cartContent.style.display = 'block';
    
    let total = 0;
    
    cartBody.innerHTML = cart.map(item => {
        const product = products.find(p => p.id === item.productId);
        if (!product) return '';
        
        const itemTotal = product.price * item.quantity;
        total += itemTotal;
        
        return `
            <div class="cart-item">
                <img src="${product.image}" alt="${product.name}" class="cart-image">
                <div class="cart-info">
                    <h6 class="cart-name">${product.name}</h6>
                    <span class="cart-price">$${product.price?.toLocaleString() || '0'}</span>
                </div>
                <div class="cart-quantity">
                    <button class="btn btn-sm btn-outline-secondary" onclick="updateCartQuantity('${item.recordId}', ${item.quantity - 1})">-</button>
                    <span class="quantity-display">${item.quantity}</span>
                    <button class="btn btn-sm btn-outline-secondary" onclick="updateCartQuantity('${item.recordId}', ${item.quantity + 1})">+</button>
                </div>
                <div class="cart-item-total">
                    $${itemTotal.toLocaleString()}
                </div>
                <button class="btn btn-sm btn-outline-danger" onclick="removeFromCart('${item.recordId}')">
                    <i class="bi bi-trash"></i>
                </button>
            </div>
        `;
    }).join('');
    
    cartTotal.textContent = `$${total.toLocaleString()}`;
}

// Actualizar cantidad en carrito
async function updateCartQuantity(recordId, newQuantity) {
    if (newQuantity < 1) {
        removeFromCart(recordId);
        return;
    }
    
    try {
        await airtableService.updateCartItem(recordId, newQuantity);
        const item = cart.find(item => item.recordId === recordId);
        if (item) {
            item.quantity = newQuantity;
        }
        renderCart();
    } catch (error) {
        console.error('Error actualizando cantidad:', error);
    }
}

// Eliminar item del carrito
async function removeFromCart(recordId) {
    try {
        await airtableService.removeFromCart(recordId);
        cart = cart.filter(item => item.recordId !== recordId);
        renderCart();
    } catch (error) {
        console.error('Error eliminando del carrito:', error);
    }
}

// Vaciar carrito
async function clearCart() {
    if (!confirm('¿Estás seguro de que quieres vaciar tu carrito?')) {
        return;
    }
    
    try {
        for (const item of cart) {
            await airtableService.removeFromCart(item.recordId);
        }
        cart = [];
        renderCart();
    } catch (error) {
        console.error('Error vaciando carrito:', error);
    }
}

// Checkout
async function checkout() {
    if (cart.length === 0) {
        alert('Tu carrito está vacío');
        return;
    }
    
    try {
        // Marcar productos como vendidos
        for (const item of cart) {
            const product = products.find(p => p.id === item.productId);
            if (product) {
                await airtableService.updateProductStatus(product.id, 'sold');
            }
        }
        
        // Vaciar carrito
        await clearCart();
        
        // Mostrar mensaje de éxito
        showCheckoutSuccess();
        
        // Recargar productos
        await loadProducts();
        renderProducts();
        
    } catch (error) {
        console.error('Error en checkout:', error);
        alert('❌ Error al procesar la compra');
    }
}

// Mostrar éxito de checkout
function showCheckoutSuccess() {
    const checkoutSuccess = document.getElementById('checkoutSuccess');
    checkoutSuccess.style.display = 'block';
    
    setTimeout(() => {
        checkoutSuccess.style.display = 'none';
        closeCartPopup();
    }, 3000);
}

// Filter and search
function filterProducts() {
    const searchTerm = document.getElementById('searchInput').value.toLowerCase();
    const category = document.getElementById('categoryFilter').value;
    const productItems = document.querySelectorAll('.product-item');
    
    productItems.forEach(item => {
        const productName = item.getAttribute('data-name');
        const productCategory = item.getAttribute('data-category');
        
        const matchesSearch = productName.includes(searchTerm);
        const matchesCategory = category === 'all' || productCategory === category;
        
        item.style.display = (matchesSearch && matchesCategory) ? 'block' : 'none';
    });
}

// Sort products
function sortProducts() {
    const sortBy = document.getElementById('sortFilter').value;
    let sortedProducts = [...products];
    
    switch(sortBy) {
        case 'price-asc':
            sortedProducts.sort((a, b) => a.price - b.price);
            break;
        case 'price-desc':
            sortedProducts.sort((a, b) => b.price - a.price);
            break;
        case 'name':
            sortedProducts.sort((a, b) => a.name.localeCompare(b.name));
            break;
    }
    
    products = sortedProducts;
    renderProducts();
}

// Popup de detalles del producto - VERSIÓN CON CREADOR
function openProductPopup(productId) {
    const product = products.find(p => p.id === productId);
    if (!product) return;

    currentProductId = productId;

    // Actualizar información en el popup
    document.getElementById('popupProductName').textContent = product.name;
    document.getElementById('popupProductImage').src = product.image;
    document.getElementById('popupProductCategory').textContent = 
        product.category?.charAt(0)?.toUpperCase() + product.category?.slice(1) || 'Sin categoría';
    document.getElementById('popupProductPrice').textContent = `$${product.price?.toLocaleString() || '0'}`;
    document.getElementById('popupProductDescription').textContent = product.description || 'Sin descripción disponible';
    document.getElementById('popupProductCreatedBy').textContent = product.createdBy || 'Anónimo'; // Nuevo campo
    
    // Actualizar estado basado solo en IsAvailable
    const statusBadge = document.getElementById('popupProductStatus');
    const stockInfo = document.getElementById('popupProductStock');
    
    if (product.isAvailable) {
        statusBadge.textContent = 'Disponible';
        statusBadge.className = 'badge bg-success';
        stockInfo.textContent = 'Disponible para compra';
        stockInfo.className = 'text-success';
    } else {
        statusBadge.textContent = 'Agotado';
        statusBadge.className = 'badge bg-warning';
        stockInfo.textContent = 'Producto agotado';
        stockInfo.className = 'text-danger';
    }

    // Actualizar botones
    const wishlistBtn = document.getElementById('wishlistBtn');
    const cartBtn = document.getElementById('cartBtn');
    
    wishlistBtn.innerHTML = wishlist.includes(productId) ? 
        '<i class="bi bi-heart-fill"></i> En wishlist' : 
        '<i class="bi bi-heart"></i> Wishlist';
    
    wishlistBtn.className = wishlist.includes(productId) ? 
        'btn btn-danger' : 'btn btn-outline-danger';

    // Habilitar/deshabilitar carrito basado solo en IsAvailable
    cartBtn.disabled = !product.isAvailable;
    cartBtn.innerHTML = cartBtn.disabled ? 
        '<i class="bi bi-cart-x"></i> No disponible' : 
        '<i class="bi bi-cart-plus"></i> Agregar al Carrito';

    // Mostrar popup
    document.getElementById('productDetailPopup').style.display = 'block';
    document.getElementById('overlay').style.display = 'block';
}

// Función para agregar al carrito - VERSIÓN SIMPLIFICADA
async function addToCart(productId) {
    if (!authService.isAuthenticated()) {
        alert('Debes iniciar sesión para agregar al carrito');
        return;
    }

    const product = products.find(p => p.id === productId);
    if (!product || !product.isAvailable) {
        alert('❌ Este producto no está disponible');
        return;
    }

    const userId = authService.getCurrentUser().id;
    
    try {
        await airtableService.addToCart(userId, productId);
        alert('✅ Producto agregado al carrito');
        
        // Opcional: Aquí podrías actualizar el estado a "agotado" después de la compra
        // product.isAvailable = false;
        // renderProducts();
        
    } catch (error) {
        console.error('Error agregando al carrito:', error);
        alert('❌ Error al agregar al carrito');
    }
}

// Función para agregar al carrito desde el popup
function addToCartPopup(productId) {
    addToCart(productId);
    
    // Mostrar feedback visual
    const cartBtn = document.getElementById('cartBtn');
    const originalText = cartBtn.innerHTML;
    
    if (!cartBtn.disabled) {
        cartBtn.innerHTML = '<i class="bi bi-check-lg"></i> ¡Agregado!';
        cartBtn.disabled = true;
        
        setTimeout(() => {
            cartBtn.innerHTML = originalText;
            cartBtn.disabled = false;
        }, 2000);
    }
}

// Mostrar mensaje de error
function showErrorMessage(message) {
    console.error('❌ Error:', message);
    alert(message);
}

// =============================================
// FUNCIONES PARA EL FORMULARIO VENDER
// =============================================

// Mostrar mensajes en el formulario de vender
function showSellMessage(message, type = 'success') {
    const statusDiv = document.getElementById('sellStatusMessage');
    statusDiv.className = `alert alert-${type}`;
    statusDiv.innerHTML = message;
    statusDiv.style.display = 'block';
    
    if (type === 'success') {
        setTimeout(() => {
            statusDiv.style.display = 'none';
        }, 5000);
    }
}

// Vista previa de imagen desde URL
document.addEventListener('DOMContentLoaded', function() {
    const imageUrlInput = document.getElementById('productImageURL');
    if (imageUrlInput) {
        imageUrlInput.addEventListener('input', function() {
            const url = this.value;
            const preview = document.getElementById('urlPreview');
            const previewContainer = document.getElementById('urlImagePreview');
            
            if (url && isValidURL(url)) {
                preview.src = url;
                preview.onload = function() {
                    previewContainer.style.display = 'block';
                };
                preview.onerror = function() {
                    previewContainer.style.display = 'none';
                    showSellMessage('❌ No se pudo cargar la imagen desde esta URL', 'danger');
                };
            } else {
                previewContainer.style.display = 'none';
            }
        });
    }
});

// Validar URL
function isValidURL(string) {
    try {
        new URL(string);
        return true;
    } catch (_) {
        return false;
    }
}

// Guardar producto en Airtable - VERSIÓN SIMPLIFICADA
async function saveProductToAirtable(productData) {
    const productRecord = {
        fields: {
            "Nombre": productData.name,
            "Descripcion": productData.description,
            "Precio": parseFloat(productData.price),
            "Categoria": productData.category,
            "Status": productData.status,
            "ImagenUrl": productData.imageURL,
            "Fecha": new Date().toISOString().split('T')[0],
            "CreatedBy": productData.createdBy // SOLO ESTE CAMPO
        }
    };

    try {
        const response = await fetch(`https://api.airtable.com/v0/${AIRTABLE_PRODUCTS_CONFIG.BASE_ID}/${AIRTABLE_PRODUCTS_CONFIG.TABLE_NAME}`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${AIRTABLE_PRODUCTS_CONFIG.ACCESS_TOKEN}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(productRecord)
        });

        if (response.ok) {
            const data = await response.json();
            return { success: true, data: data };
        } else {
            const errorText = await response.text();
            return { 
                success: false, 
                error: `Error ${response.status}: ${errorText}` 
            };
        }
    } catch (error) {
        return { 
            success: false, 
            error: `Error de conexión: ${error.message}` 
        };
    }
}

// Manejar envío del formulario de vender - VERSIÓN CON USUARIO CREADOR
async function handleSellForm(event) {
    event.preventDefault();
    
    // Verificar que el usuario esté autenticado
    if (!authService.isAuthenticated()) {
        showSellMessage('❌ Debes iniciar sesión para vender productos', 'danger');
        return;
    }

    const user = authService.getCurrentUser();
    
    // Obtener valores del formulario
    const productData = {
        name: document.getElementById('productName').value,
        description: document.getElementById('productDescription').value,
        price: document.getElementById('productPrice').value,
        category: document.getElementById('productCategory').value,
        status: document.getElementById('productStatus').value,
        imageURL: document.getElementById('productImageURL').value,
        createdBy: user.name // SOLO GUARDAMOS EL NOMBRE
    };
    
    // Validaciones
    if (productData.price <= 0) {
        showSellMessage('❌ El precio debe ser mayor a 0', 'danger');
        return;
    }
    
    if (!isValidURL(productData.imageURL)) {
        showSellMessage('❌ Ingresa una URL de imagen válida', 'danger');
        return;
    }
    
    if (!productData.category) {
        showSellMessage('❌ Selecciona una categoría', 'danger');
        return;
    }

    // Cambiar texto del botón a "Publicando..."
    const submitButton = document.getElementById('submitButton');
    const originalText = submitButton.innerHTML;
    submitButton.innerHTML = '<i class="bi bi-hourglass-split me-2"></i>Publicando...';
    submitButton.disabled = true;

    // Mostrar mensaje de carga
    showSellMessage('<i class="bi bi-hourglass-split me-2"></i>Publicando producto en la tienda...', 'info');

    // Guardar en Airtable
    const result = await saveProductToAirtable(productData);

    if (result.success) {
        showSellMessage(`
            ✅ ¡Producto publicado exitosamente!<br>
            <small>Tu producto ahora está en la tienda de GreenCash</small>
        `, 'success');
        
        console.log('Producto creado:', result.data);
        
        // Limpiar formulario
        document.getElementById('sellForm').reset();
        document.getElementById('urlImagePreview').style.display = 'none';
        
        // Recargar productos en la tienda después de 2 segundos
        setTimeout(() => {
            if (typeof initializeStore === 'function') {
                initializeStore();
            }
            closeSellPopup();
        }, 2000);
        
    } else {
        showSellMessage(`❌ Error al publicar producto: ${result.error}`, 'danger');
        
        // Restaurar botón
        submitButton.innerHTML = originalText;
        submitButton.disabled = false;
    }
}

// Guardar producto en Airtable - VERSIÓN CON USUARIO CREADOR
async function saveProductToAirtable(productData) {
    const productRecord = {
        fields: {
            "Nombre": productData.name,
            "Descripcion": productData.description,
            "Precio": parseFloat(productData.price),
            "Categoria": productData.category,
            "Status": productData.status,
            "ImagenUrl": productData.imageURL,
            "Fecha": new Date().toISOString().split('T')[0],
            "CreatedBy": productData.createdBy, // Nuevo campo
            "CreatedById": productData.createdById // Nuevo campo
        }
    };

    try {
        const response = await fetch(`https://api.airtable.com/v0/${AIRTABLE_PRODUCTS_CONFIG.BASE_ID}/${AIRTABLE_PRODUCTS_CONFIG.TABLE_NAME}`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${AIRTABLE_PRODUCTS_CONFIG.ACCESS_TOKEN}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(productRecord)
        });

        if (response.ok) {
            const data = await response.json();
            return { success: true, data: data };
        } else {
            const errorText = await response.text();
            return { 
                success: false, 
                error: `Error ${response.status}: ${errorText}` 
            };
        }
    } catch (error) {
        return { 
            success: false, 
            error: `Error de conexión: ${error.message}` 
        };
    }
}

// Función para abrir el popup de vender con configuración
function openSellPopup() {
    // Verificar si el usuario está logueado
    if (!authService.isAuthenticated()) {
        alert('⚠️ Debes iniciar sesión para vender productos');
        return;
    }
    
    // Mostrar información del usuario que vende
    const user = authService.getCurrentUser();
    document.getElementById('sellStatusMessage').innerHTML = `
        <small>Vendiendo como: <strong>${user.name}</strong></small>
    `;
    document.getElementById('sellStatusMessage').className = 'alert alert-info';
    document.getElementById('sellStatusMessage').style.display = 'block';
    
    // Abrir popup
    document.getElementById('sellPopup').style.display = 'block';
    document.getElementById('overlay').style.display = 'block';
}

// =============================================
// FUNCIONES DE POPUP EXISTENTES
// =============================================

function openWishlistPopup() {
    document.getElementById('wishlistPopup').style.display = 'block';
    document.getElementById('overlay').style.display = 'block';
}

function closeWishlistPopup() {
    document.getElementById('wishlistPopup').style.display = 'none';
    document.getElementById('overlay').style.display = 'none';
}

function openCartPopup() {
    document.getElementById('cartPopup').style.display = 'block';
    document.getElementById('overlay').style.display = 'block';
}

function closeCartPopup() {
    document.getElementById('cartPopup').style.display = 'none';
    document.getElementById('overlay').style.display = 'none';
}

function closeSellPopup() {
    document.getElementById('sellPopup').style.display = 'none';
    document.getElementById('overlay').style.display = 'none';
}

// Cerrar popup de producto - DEBE ESTAR EN tu tienda.js
function closeProductPopup() {
    document.getElementById('productDetailPopup').style.display = 'none';
    document.getElementById('overlay').style.display = 'none';
    currentProductId = null;
}

// Cerrar todos los popups (función existente)
function closeAllPopups() {
    closeProductPopup();
    closeWishlistPopup();
    closeCartPopup();
    closeSellPopup();
}
// Cerrar popups con tecla ESC (OPCIONAL)
document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape') {
        closeAllPopups();
    }
});
// Vista previa de imagen
function previewImage(event) {
    const input = event.target;
    const preview = document.getElementById('preview');
    const imagePreview = document.getElementById('imagePreview');
    
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = function(e) {
            preview.src = e.target.result;
            imagePreview.style.display = 'block';
        }
        reader.readAsDataURL(input.files[0]);
    }
}

function removeImage() {
    document.getElementById('productImage').value = '';
    document.getElementById('imagePreview').style.display = 'none';
}


// =============================================
// INICIALIZACIÓN
// =============================================

document.addEventListener('DOMContentLoaded', function() {
    authService.restoreSession();
    if (document.getElementById('productsGrid')) {
        initializeStore();
    }
});